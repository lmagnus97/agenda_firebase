import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:alice/alice.dart';

class AppWidget extends StatelessWidget {
  final alice = Alice();


  @override
  Widget build(BuildContext context) {
    Modular.routerDelegate.setNavigatorKey(alice.getNavigatorKey());
    return MaterialApp.router(
      title: 'Agenda esportiva',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      routerDelegate: Modular.routerDelegate,
      routeInformationParser: Modular.routeInformationParser,
    );
  }
}
