class Messages {
  static const String messageError = "Falha ao recuperar dados";
  static const String messageEmpty = "Nenhum registro encontrado";
}

class Routes {
  static const home = "/";
}