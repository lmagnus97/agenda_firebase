import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class Utils{
  static bool isNullOrEmptyList(List<dynamic>? data){
    return data == null || data.isEmpty;
  }

  static String formatToTime(Timestamp timestamp) {
    return DateFormat('hh:mm').format(timestamp.toDate());
  }

  static String getFormatedDateTitle(DateTime dateTime) {
    return DateFormat('dd/MM').format(dateTime);
  }
}