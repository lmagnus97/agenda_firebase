class HomeRouters {
  static const home = "/";
}